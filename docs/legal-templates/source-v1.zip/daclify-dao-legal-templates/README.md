# Daclify DAO Legal & Governance Templates

A collection of **12 editable Markdown drafts** for communities and DAOs using Daclify (or another governance platform).

**Status:** Draft templates, version 1.0. **These are not jurisdiction-specific legal advice or ready-to-sign legal instruments.** Using or approving a governance document does not automatically incorporate a legal entity, limit liability, authorize regulated financial activities, or make a contract enforceable. Review with appropriately qualified legal counsel for the DAO's country, legal structure, participants and operations.

## Files

| File | Document |
|---|---|
| [`01-dao-constitution-charter.md`](01-dao-constitution-charter.md) | DAO Constitution and Charter |
| [`02-dao-membership-agreement.md`](02-dao-membership-agreement.md) | DAO Membership Agreement |
| [`03-governance-voting-policy.md`](03-governance-voting-policy.md) | Governance and Voting Policy |
| [`04-treasury-management-spending-policy.md`](04-treasury-management-spending-policy.md) | Treasury Management and Spending Policy |
| [`05-code-of-conduct.md`](05-code-of-conduct.md) | DAO Code of Conduct |
| [`06-conflict-of-interest-policy.md`](06-conflict-of-interest-policy.md) | Conflict of Interest Policy |
| [`07-contributor-project-agreement.md`](07-contributor-project-agreement.md) | Contributor and Project Agreement |
| [`08-dispute-resolution-policy.md`](08-dispute-resolution-policy.md) | DAO Dispute Resolution Policy |
| [`09-privacy-confidentiality-policy.md`](09-privacy-confidentiality-policy.md) | DAO Privacy and Confidentiality Policy |
| [`10-dao-dissolution-policy.md`](10-dao-dissolution-policy.md) | DAO Dissolution and Asset Distribution Policy |
| [`11-delegation-authority-policy.md`](11-delegation-authority-policy.md) | Delegation of Authority Policy |
| [`12-governance-amendment-document-control-policy.md`](12-governance-amendment-document-control-policy.md) | Governance Amendment and Document Control Policy |

## How to customize

1. Choose a template and replace all **`[PLACEHOLDER]`** values with real DAO details. Leave none unresolved before adoption.
2. Confirm the legal entity (if any), contracting party, governing law, and actual governance mechanism. Do not assume a DAO vote can enter contracts on its own.
3. Align quorum, eligible votes, approval thresholds, roles, spending limits and deadlines with the real system and applicable governing instruments.
4. Have qualified counsel review documents that will be binding, especially contributor agreements, privacy notices, asset rights and dissolution procedures.
5. Record the final document version, approval ID, effective date and any required signatures. Preserve superseded versions.

### Daclify integration ideas

The placeholders are intentionally simple (`[DAO_NAME]`, `[EFFECTIVE_DATE]`, etc.) to support future rendering. A template engine can extract them using the regular expression `\[([A-Z][A-Z0-9_]*)\]`. Do not automatically publish or enforce unreviewed generated documents. An accepted proposal is not necessarily an executed legal document.

### Scope

These 12 drafts are **DAO governance and member-facing documents**, not Daclify platform Terms of Service, platform Privacy Policy or jurisdiction-specific incorporation/operating agreements. Such documents should be drafted separately.
